COOKIE_SECURE = False # if True it will send cookies only via HTTPS
MESSAGE_LIMIT = 10